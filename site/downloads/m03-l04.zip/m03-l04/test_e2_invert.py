from e2_invert import invert


def test_swaps_keys_and_values():
    assert invert({"a": 1, "b": 2}) == {1: "a", 2: "b"}


def test_works_with_string_values():
    assert invert({"MY": "Malaysia", "JP": "Japan"}) == {"Malaysia": "MY", "Japan": "JP"}


def test_empty_dict():
    assert invert({}) == {}


def test_does_not_change_the_original():
    d = {"x": 10}
    result = invert(d)
    assert d == {"x": 10}
    assert result is not d, "build a brand-new dictionary"


def test_many_pairs():
    codes = {i: str(i) for i in range(100)}
    assert invert(codes) == {str(i): i for i in range(100)}
