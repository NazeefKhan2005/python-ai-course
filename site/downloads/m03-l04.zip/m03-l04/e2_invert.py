def invert(d):
    """Return a NEW dict with keys and values swapped (values are unique)."""
    pass
