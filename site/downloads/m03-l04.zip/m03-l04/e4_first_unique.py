def first_unique_index(s):
    """Index of the first character that appears exactly once in s, else -1."""
    return -1
