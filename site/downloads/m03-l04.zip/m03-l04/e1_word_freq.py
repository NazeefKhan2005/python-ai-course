def word_freq(text):
    """Return a dict mapping each lower-case word in text to its count."""
    counts = {}
    # your code here
    return counts


if __name__ == "__main__":
    print(word_freq("the cat the hat"))
