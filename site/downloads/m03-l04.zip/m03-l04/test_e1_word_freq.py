from e1_word_freq import word_freq


def test_counts_repeated_words():
    assert word_freq("the cat the hat") == {"the": 2, "cat": 1, "hat": 1}


def test_treats_upper_and_lower_case_as_one_word():
    assert word_freq("Data data DATA") == {"data": 3}


def test_empty_text_gives_an_empty_dict():
    assert word_freq("") == {}


def test_returns_a_dict_instead_of_printing():
    assert isinstance(word_freq("a b"), dict), "end with: return counts"


def test_splits_on_any_whitespace():
    assert word_freq("  spaced   out\nwords  ") == {"spaced": 1, "out": 1, "words": 1}
