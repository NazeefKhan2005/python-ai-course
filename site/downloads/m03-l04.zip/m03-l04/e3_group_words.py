def group_by_first_letter(words):
    """Group words by lower-case first letter, keeping their order."""
    groups = {}
    for word in words:
        ...  # your code here
    return groups
