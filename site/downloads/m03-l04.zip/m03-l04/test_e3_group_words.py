from e3_group_words import group_by_first_letter


def test_groups_words():
    assert group_by_first_letter(["apple", "avocado", "banana"]) == {"a": ["apple", "avocado"], "b": ["banana"]}


def test_keeps_the_original_order_inside_a_group():
    assert group_by_first_letter(["bee", "ant", "bat"])["b"] == ["bee", "bat"]


def test_keys_are_lower_case_and_words_unchanged():
    assert group_by_first_letter(["Python", "pandas"]) == {"p": ["Python", "pandas"]}


def test_empty_list():
    assert group_by_first_letter([]) == {}


def test_skips_empty_strings_and_leaves_the_input_alone():
    words = ["", "x-ray", "", "Xylo"]
    assert group_by_first_letter(words) == {"x": ["x-ray", "Xylo"]}
    assert words == ["", "x-ray", "", "Xylo"]
