from course_helpers import assert_fast_enough
from e4_first_unique import first_unique_index


def linear_reference(s):
    counts = {}
    for ch in s:
        counts[ch] = counts.get(ch, 0) + 1
    return next((i for i, ch in enumerate(s) if counts[ch] == 1), -1)


def test_first_character_is_unique():
    assert first_unique_index("leetcode") == 0


def test_skips_repeated_characters():
    assert first_unique_index("loveleetcode") == 2


def test_no_unique_character():
    assert first_unique_index("aabb") == -1


def test_empty_string():
    assert first_unique_index("") == -1


def test_case_matters():
    assert first_unique_index("Aa") == 0


def test_fast_on_40_001_characters():
    s = "ab" * 20_000 + "c"
    assert first_unique_index(s) == 40_000
    assert_fast_enough(first_unique_index, linear_reference, s, factor=10)
