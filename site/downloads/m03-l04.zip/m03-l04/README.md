# M03-L04 · Dictionaries — exercise pack

Lesson page: site/modules/m03-data-structures/l04-dictionaries.html

## How to work on these exercises

1. Open this folder in your editor and in a terminal (see the course setup page).
2. Install pytest once per environment: `python -m pip install pytest`
3. Run every exercise's tests: `python -m pytest`
   or a single exercise: `python -m pytest test_e1_....py`
4. Edit the `eN_*.py` files until their tests pass. When a whole test file passes, pytest
   prints a completion code: paste it into the exercise on the lesson page.

On Windows use `py` instead of `python`; with uv use `uv run --with pytest pytest`.

## Exercises

- **m03-l04-e1** Exercise 1 · Word frequencies: edit `e1_word_freq.py`, check with `python -m pytest test_e1_word_freq.py`
- **m03-l04-e2** Exercise 2 · Flip a dictionary: edit `e2_invert.py`, check with `python -m pytest test_e2_invert.py`
- **m03-l04-e3** Exercise 3 · Group words by first letter: edit `e3_group_words.py`, check with `python -m pytest test_e3_group_words.py`
- **m03-l04-e4** Exercise 4 · First unique character (interview challenge) (optional): edit `e4_first_unique.py`, check with `python -m pytest test_e4_first_unique.py`
